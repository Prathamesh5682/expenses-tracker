import { useState, useEffect } from 'react';
import { fetchExpenses, createExpense, updateExpense, deleteExpense } from './services/api';
import ExpenseForm from './components/ExpenseForm';
import ExpenseList from './components/ExpenseList';
import Dashboard from './components/Dashboard';

export default function App() {
  const [expenses, setExpenses] = useState([]);
  const [editingExpense, setEditingExpense] = useState(null);

  const loadExpenses = async () => {
    const { data } = await fetchExpenses();
    setExpenses(data);
  };

  useEffect(() => {
    loadExpenses();
  }, []);

  const addExpense = async (expense) => {
    await createExpense(expense);
    loadExpenses();
  };

  const editExpense = (expense) => {
    setEditingExpense(expense);
  };

  const updateExpenseHandler = async (expense) => {
    await updateExpense(expense.id, expense);
    loadExpenses();
  };

  const deleteExpenseHandler = async (id) => {
    await deleteExpense(id);
    loadExpenses();
  };

  const clearEditing = () => {
    setEditingExpense(null);
  };

  return (
    <div className="App">
      <h1>Expense Tracker</h1>
      <ExpenseForm addExpense={addExpense} editingExpense={editingExpense} updateExpense={updateExpenseHandler} clearEditing={clearEditing} />
      <ExpenseList expenses={expenses} onEdit={editExpense} onDelete={deleteExpenseHandler} />
      <Dashboard expenses={expenses} />
    </div>
  );
}
