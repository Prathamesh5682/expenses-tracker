export default function ExpenseList({ expenses, onEdit, onDelete }) {
    return (
      <div>
        <h2>Expenses</h2>
        <ul>
          {expenses.map((exp) => (
            <li key={exp.id}>
              ₹{exp.amount} - {exp.category} ({exp.date})
              <button onClick={() => onEdit(exp)}>Edit</button>
              <button onClick={() => onDelete(exp.id)}>Delete</button>
            </li>
          ))}
        </ul>
      </div>
    );
  }
  