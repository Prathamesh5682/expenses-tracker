import { useState, useEffect } from 'react';

export default function ExpenseForm({ addExpense, editingExpense, updateExpense, clearEditing }) {
  const [expense, setExpense] = useState({ amount: '', category: '', description: '', date: '' });

  useEffect(() => {
    if (editingExpense) {
      setExpense(editingExpense);
    }
  }, [editingExpense]);

  const handleChange = (e) => {
    setExpense({ ...expense, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingExpense) {
      updateExpense(expense);
    } else {
      addExpense(expense);
    }
    setExpense({ amount: '', category: '', description: '', date: '' });
    clearEditing();
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="amount" value={expense.amount} onChange={handleChange} placeholder="Amount" required />
      <input name="category" value={expense.category} onChange={handleChange} placeholder="Category" required />
      <input name="description" value={expense.description} onChange={handleChange} placeholder="Description" />
      <input name="date" type="date" value={expense.date} onChange={handleChange} required />
      <button type="submit">{editingExpense ? 'Update' : 'Add'} Expense</button>
    </form>
  );
}
