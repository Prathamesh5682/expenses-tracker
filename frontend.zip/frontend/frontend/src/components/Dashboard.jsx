import { Pie, Bar } from 'react-chartjs-2';

export default function Dashboard({ expenses }) {
  const categoryTotals = {};
  const monthlyTotals = {};

  expenses.forEach((exp) => {
    categoryTotals[exp.category] = (categoryTotals[exp.category] || 0) + parseFloat(exp.amount);

    const month = new Date(exp.date).toLocaleString('default', { month: 'short', year: 'numeric' });
    monthlyTotals[month] = (monthlyTotals[month] || 0) + parseFloat(exp.amount);
  });

  const pieData = {
    labels: Object.keys(categoryTotals),
    datasets: [{ data: Object.values(categoryTotals), backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0'] }]
  };

  const barData = {
    labels: Object.keys(monthlyTotals),
    datasets: [{ label: 'Expenses by Month', data: Object.values(monthlyTotals), backgroundColor: '#36A2EB' }]
  };

  return (
    <div>
      <h2>Dashboard</h2>
      <Pie data={pieData} />
      <Bar data={barData} />
    </div>
  );
}
