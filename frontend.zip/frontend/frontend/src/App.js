import { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [expenses, setExpenses] = useState([]);
  const [form, setForm] = useState({ amount: '', category: '', description: '', date: '' });

  const fetchExpenses = async () => {
    const res = await fetch('http://localhost:5000/expenses');
    const data = await res.json();
    setExpenses(data);
  };

  useEffect(() => {
    fetchExpenses();
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await fetch('http://localhost:5000/expenses', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    });
    setForm({ amount: '', category: '', description: '', date: '' });
    fetchExpenses();
  };

  return (
    <div className="App">
      <h1>Expense Tracker</h1>

      <form onSubmit={handleSubmit}>
        <input type="number" name="amount" placeholder="Amount" value={form.amount} onChange={handleChange} required />
        <input type="text" name="category" placeholder="Category" value={form.category} onChange={handleChange} required />
        <input type="text" name="description" placeholder="Description" value={form.description} onChange={handleChange} required />
        <input type="date" name="date" value={form.date} onChange={handleChange} required />
        <button type="submit">Add Expense</button>
      </form>

      <h2>All Expenses</h2>
      <ul>
        {expenses.map(exp => (
          <li key={exp.id}>
            ₹{exp.amount} - {exp.category} ({exp.description}) on {new Date(exp.date).toLocaleDateString()}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
